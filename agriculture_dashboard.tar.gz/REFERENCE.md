# 📐 Quick Reference: Formulas & Constants

## 🎯 OPTIMAL SOLUTION (From Paper - Table 6)

### Optimal Factors
```
Irrigation:  1100.0 m³/ha
Nitrogen:      57.2 kg/ha
Density:       10.0 plants/m²
```

### Optimal Responses
```
Production:  6324.2 kg/ha
EUN:           54.6 kg maize/kg N
EUA:            5.7 kg maize/m³
RBC:            2.3
```

### Costs
```
Nitrogen Cost:      $0.2/ha
Irrigation Cost:    $3.2/ha
Total Production:  $916.9/ha
```

### Desirability
```
Combined Desirability: 0.74
```

---

## 📊 FACTOR RANGES

| Factor | Symbol | Min | Max | Unit | Levels |
|--------|--------|-----|-----|------|--------|
| Irrigation | I | 1100 | 3000 | m³/ha | 1100, 2050, 3000 |
| Nitrogen | N | 0 | 150 | kg/ha | 0, 75, 150 |
| Density | D | 3.3 | 10 | plants/m² | 3.3, 6.65, 10.0 |

---

## 📈 RESPONSE RANGES (From Actual Data)

| Response | Symbol | Min | Max | Unit | Goal |
|----------|--------|-----|-----|------|------|
| Production | Y | 4385 | 7400 | kg/ha | Maximize |
| EUN | - | 34.6 | 73.4 | kg/kg | Maximize |
| EUA | - | 1.7 | 6.0 | kg/m³ | Maximize |
| RBC | - | 1.5 | 2.4 | - | Maximize |

---

## 🧮 FORMULAS

### 1. Nitrogen Use Efficiency (EUN)
**Equation 3 (Page 6)**
```python
EUN = Production / (Ni + 0.46 * Na)

Where:
  Production = maize yield (kg/ha)
  Ni = 90 kg/ha  # Nitrogen in soil before fertilization
  Na = Nitrogen applied (kg/ha)
  0.46 = conversion factor
```

**Example:**
```python
Production = 6324.2 kg/ha
Na = 57.2 kg/ha
Ni = 90 kg/ha

EUN = 6324.2 / (90 + 0.46 * 57.2)
    = 6324.2 / (90 + 26.3)
    = 6324.2 / 116.3
    = 54.4 kg/kg
```

---

### 2. Water Use Efficiency (EUA)
**Equation 4 (Page 6)**
```python
EUA = Production / Irrigation

Where:
  Production = maize yield (kg/ha)
  Irrigation = water applied (m³/ha)
```

**Example:**
```python
Production = 6324.2 kg/ha
Irrigation = 1100 m³/ha

EUA = 6324.2 / 1100
    = 5.75 kg/m³
```

---

### 3. Benefit-Cost Ratio (RBC)
**Equations 5-8 (Page 7)**

```python
# Revenue
Revenue = Production * Price_per_kg

# Costs
Cost_Nitrogen = Na * Unit_Cost_N
Cost_Irrigation = Irrigation * Unit_Cost_Water
Total_Cost = Fixed_Cost + Cost_Nitrogen + Cost_Irrigation

# RBC
RBC = Revenue / Total_Cost
```

**Constants (November 2016 prices from paper):**
```python
Price_per_kg = 0.30  # $/kg maize (US$ 200 Bs → $0.30 USD)
Unit_Cost_N = 0.0035  # $/kg nitrogen (estimated)
Unit_Cost_Water = 0.0029  # $/m³ (from HIDROVEN tariff)
Fixed_Cost = 913.44  # $/ha (US$ 601,274 Bs → $913.44 USD)
```

**Example:**
```python
Production = 6324.2 kg/ha
Na = 57.2 kg/ha
Irrigation = 1100 m³/ha

Revenue = 6324.2 * 0.30 = 1897.26

Cost_N = 57.2 * 0.0035 = 0.20
Cost_Water = 1100 * 0.0029 = 3.19
Total_Cost = 913.44 + 0.20 + 3.19 = 916.83

RBC = 1897.26 / 916.83 = 2.07
```

---

## 📐 POLYNOMIAL MODELS (For Prediction)

### Production Model
**Equation 16 (Page 14)**
```python
Production = 5585.7 - 0.53*I + 28.9*N - 283.4*D - 0.115*N² + 26.1*D²

Where:
  I = Irrigation (m³/ha)
  N = Nitrogen (kg/ha)
  D = Density (plants/m²)
```

### EUN Model (Log Transformed)
**Equation 17 (Page 14)**
```python
ln(EUN) = 4.06 - 6.942e-5*I + 0.00052*N - 0.042*D 
          - 1.3204e-5*N² + 0.00437*D²

Then: EUN = exp(ln(EUN))
```

### EUA Model (Log Transformed)
**Equation 18 (Page 14)**
```python
ln(EUA) = 2.58 - 0.001*I + 0.005*N - 0.04*D 
          + 1.68e-7*I² - 2.03e-5*N² + 0.0043*D²

Then: EUA = exp(ln(EUA))
```

### RBC Model
**Equation 19 (Page 14)**
```python
RBC = 2.17 + 0.01*N - 0.09*D - 3.9e-5*N² + 0.009*D²
```

**Note:** These models use actual (not coded) factor values

---

## 🎲 EXPERIMENTAL DESIGN DETAILS

### Design Type
```
Central Composite Design (CCD)
Face-Centered (α = 1)
```

### Structure
```
Factorial points:   2³ = 8
Axial points:       2×3 = 6
Center points:      2
                    ------
Unique treatments:  16

Blocks:             3
Total runs:         16 × 3 = 48
```

### Coded Values
```
Level    -1      0      1
I:      1100   2050   3000
N:         0     75    150
D:       3.3   6.65   10.0
```

---

## 🎨 USTA COLOR PALETTE

```python
USTA_COLORS = {
    "primary": "#0a2f6b",      # Dark blue
    "secondary": "#1d4f91",    # Medium blue
    "accent": "#f9a602",       # Gold
    "teal": "#1c9c9c",         # Teal (support)
    "neutral_light": "#f5f7fa",
    "neutral_dark": "#17213c"
}
```

---

## 📊 STATISTICAL METRICS (R²)

| Response | R² | R² Adjusted | R² Predicted |
|----------|-----|-------------|--------------|
| Production | 0.84 | 0.80 | 0.74 |
| EUN | 0.91 | 0.89 | 0.86 |
| EUA | 0.98 | 0.98 | 0.97 |
| RBC | 0.80 | 0.76 | 0.69 |

All models are statistically significant (p < 0.0001)

---

## 🌡️ DESIRABILITY FUNCTION

### Individual Desirability (Maximize)
```python
if y < L:         d = 0
if L ≤ y ≤ T:     d = ((y - L) / (T - L))^r
if y > T:         d = 1

Where:
  L = Lower limit
  T = Target (maximum in data)
  r = Weight (usually 1)
```

### Combined Desirability
```python
D = (d1 × d2 × d3 × d4)^(1/4)
  = 0.74

Where:
  d1 = desirability(Production)
  d2 = desirability(EUN)
  d3 = desirability(EUA)
  d4 = desirability(RBC)
```

---

## 📖 PAPER CITATION

```
Yaguas, O. J. (2017). Metodología de superficie de respuesta 
para la optimización de una producción agrícola. 
Revista Ingeniería Industrial, 16(1), 205-222.
https://doi.org/10.22320/S07179103/2017.13
```

---

## 💡 QUICK INTERPRETATION GUIDE

### What does EUN = 54.6 mean?
"For every 1 kg of nitrogen available, we produce 54.6 kg of maize"

### What does EUA = 5.7 mean?
"For every 1 m³ of irrigation water, we produce 5.7 kg of maize"

### What does RBC = 2.3 mean?
"For every $1 invested, we get $2.30 back (130% profit)"

### What does Desirability = 0.74 mean?
"The solution achieves 74% of the ideal performance across all 4 objectives"

---

**Use this reference when coding the dashboard!**
