# 🌽 Agriculture Dashboard - Implementation Checklist

## ✅ COMPLETED
- [x] Extract data from paper (Tables 1 & 2)
- [x] Create CSV file (48 runs × 11 columns)
- [x] Verify data ranges match paper
- [x] Create requirements.txt

---

## 📊 DATA COMPONENTS

### Data Files Needed
- [x] agriculture_data.csv (48 experimental runs)
- [ ] optimal_solution.json (optional - hardcode values instead)

### Data Validation
- [x] Verify 48 runs total
- [x] Verify 3 factors with 3 levels each
- [x] Verify 4 response variables
- [ ] Test data loading in Streamlit

---

## 🎨 VISUALIZATIONS TO IMPLEMENT

### Priority 1: Essential (Must Have)
- [ ] **3D Surface Plot** (Figure-style from paper)
  - Production vs Irrigation × Nitrogen
  - Production vs Irrigation × Density
  - Production vs Nitrogen × Density
  - Switch between responses (Production, EUN, EUA, RBC)

- [ ] **2D Contour Plots** (Like Figure 6)
  - Overlay multiple response contours
  - Show optimal region (gray area)

- [ ] **Factor Response Plots** (2D line/scatter)
  - Each factor vs each response
  - Show trends

### Priority 2: Good to Have
- [ ] **Comparison Charts**
  - Current selection vs optimal solution
  - Bar chart showing all 4 responses

- [ ] **Correlation Heatmap**
  - Factor correlations
  - Response correlations

### Priority 3: Nice to Have
- [ ] **Interactive Tables**
  - Show filtered data based on selections
  - Sortable columns

- [ ] **Desirability Function Visualization**
  - Show individual desirability curves
  - Show combined desirability = 0.74

---

## 🧮 CALCULATIONS TO IMPLEMENT

### Formulas from Paper

#### Response Calculations
- [ ] **EUN** (Equation 3, page 6)
  ```
  EUN = Production / (Ni + 0.46 × Na)
  Where: Ni = 90 kg/ha (soil N)
  ```

- [ ] **EUA** (Equation 4, page 6)
  ```
  EUA = Production / Irrigation
  ```

- [ ] **RBC** (Equations 5-8, page 7)
  ```
  RBC = (Production × Price) / Total_Cost
  Where:
    - Price = $0.30/kg maize
    - Cost_N = Na × $0.0035/kg
    - Cost_Water = Irrigation × $0.0029/m³
    - Fixed_Cost = $913.44/ha
  ```

#### Polynomial Models (Optional - for predictions)
- [ ] **Production Model** (Equation 16, page 14)
- [ ] **EUN Model** (Equation 17, page 14)
- [ ] **EUA Model** (Equation 18, page 14)
- [ ] **RBC Model** (Equation 19, page 14)

### Statistical Metrics
- [ ] Mean, Median, Std Dev for each response
- [ ] Min/Max for each factor and response
- [ ] Correlation coefficients

---

## 🖥️ DASHBOARD LAYOUT STRUCTURE

### Sidebar
- [ ] **Factor Controls**
  - [ ] Irrigation slider (1100-3000)
  - [ ] Nitrogen slider (0-150)
  - [ ] Density slider (3.3-10.0)
  - [ ] "Reset to Optimal" button

- [ ] **Display Options**
  - [ ] Response variable selector (Production, EUN, EUA, RBC)
  - [ ] Plot type selector (3D, Contour, 2D)
  - [ ] Color scheme selector (optional)

### Main Area - Tabs
- [ ] **Tab 1: 📊 Data Exploration**
  - [ ] Dataset overview
  - [ ] Factor distributions
  - [ ] Response distributions
  - [ ] Summary statistics table

- [ ] **Tab 2: 📈 Visualizations**
  - [ ] 3D surface plots
  - [ ] 2D contour plots
  - [ ] Factor-response plots

- [ ] **Tab 3: 🎯 Optimization**
  - [ ] Display optimal values from paper
  - [ ] Show optimization results (Table 6)
  - [ ] Comparison: User selection vs Optimal
  - [ ] Desirability = 0.74 explanation

- [ ] **Tab 4: 💰 Economic Analysis**
  - [ ] Cost breakdown
  - [ ] Revenue calculation
  - [ ] RBC analysis
  - [ ] Sensitivity analysis (optional)

- [ ] **Tab 5: 📖 About**
  - [ ] Paper citation
  - [ ] Methodology explanation
  - [ ] Design details (CCD, α=1)
  - [ ] Your names + course info

---

## 🎨 STYLING & UX

### Branding (USTA Colors - from your grading app)
- [ ] Apply USTA color palette
  - Primary: #0a2f6b
  - Accent: #f9a602
  - Teal: #1c9c9c

### User Experience
- [ ] Loading indicators for plots
- [ ] Tooltips on hover
- [ ] Clear axis labels with units
- [ ] Responsive layout (works on mobile)
- [ ] Error handling for invalid inputs

### Polish
- [ ] Professional title and header
- [ ] Favicon (optional)
- [ ] Footer with credits
- [ ] Download buttons for plots (Plotly built-in)

---

## 📊 KEY METRICS TO DISPLAY

### From Paper (Table 6, Page 16)
- [ ] **Optimal Solution**
  - Irrigation: 1100 m³/ha
  - Nitrogen: 57.2 kg/ha
  - Density: 10 plants/m²

- [ ] **Optimal Responses**
  - Production: 6324.2 kg/ha
  - EUN: 54.6 kg/kg
  - EUA: 5.7 kg/m³
  - RBC: 2.3

- [ ] **Costs**
  - Nitrogen: $0.2/ha
  - Irrigation: $3.2/ha
  - Total Production: $916.9/ha

- [ ] **Desirability**
  - Combined: 0.74

---

## 🧪 TESTING CHECKLIST

### Data Loading
- [ ] CSV loads without errors
- [ ] All 48 rows present
- [ ] All 11 columns present
- [ ] No missing values

### Visualizations
- [ ] Plots render correctly
- [ ] Axes have proper labels and units
- [ ] Colors are distinguishable
- [ ] Interactive features work (zoom, pan, hover)

### Calculations
- [ ] EUN calculated correctly
- [ ] EUA calculated correctly
- [ ] RBC calculated correctly
- [ ] Values match paper ranges

### User Interface
- [ ] Sliders move smoothly
- [ ] Selections update plots
- [ ] Tabs switch properly
- [ ] Responsive on different screen sizes

---

## 📝 DOCUMENTATION NEEDED

### In-App
- [ ] Clear instructions for users
- [ ] Explanation of each response variable
- [ ] Interpretation guide for plots
- [ ] Citation to original paper

### External (for presentation)
- [ ] README.md with setup instructions
- [ ] Screenshots of dashboard
- [ ] Explanation of design choices
- [ ] List of features implemented

---

## 🎯 MINIMUM VIABLE PRODUCT (MVP)

To have a working demo, you MUST have:
1. ✅ Data loaded and displayed
2. ⚠️ At least ONE 3D surface plot
3. ⚠️ Sidebar with factor sliders
4. ⚠️ Display optimal solution from paper
5. ⚠️ Basic styling

Everything else is bonus!

---

## 🚀 DEVELOPMENT PHASES

### Phase 1: Basic Setup (Day 1)
- [ ] Get Streamlit running
- [ ] Load and display data
- [ ] Create basic layout (sidebar + tabs)

### Phase 2: Core Features (Day 2-3)
- [ ] Implement 3D surface plots
- [ ] Add factor controls
- [ ] Show optimal solution

### Phase 3: Polish (Day 4-5)
- [ ] Add more visualizations
- [ ] Implement calculations
- [ ] Apply USTA styling

### Phase 4: Final Touches (Day 6-7)
- [ ] Add economic analysis
- [ ] Write documentation
- [ ] Test thoroughly

---

## 📋 BEFORE YOU START CODING

### Questions to Answer:
1. [ ] Do you have Python 3.8+ installed?
2. [ ] Do you have pip working?
3. [ ] Can you run `streamlit hello` successfully?
4. [ ] Do you understand the paper's methodology?
5. [ ] Do you know which features are most important?

### Files You Should Have:
- [x] agriculture_data.csv
- [x] requirements.txt
- [ ] app.py (next step!)

---

## 🎓 FOR YOUR PRESENTATION

Be ready to explain:
- [ ] Why you chose Central Composite Design
- [ ] How Response Surface Methodology works
- [ ] What the desirability function does
- [ ] How to interpret each visualization
- [ ] Practical implications for farmers

---

## 📞 SUPPORT RESOURCES

- Streamlit Docs: https://docs.streamlit.io
- Plotly Docs: https://plotly.com/python/
- Pandas Docs: https://pandas.pydata.org/docs/
- Your grading app: Reference for structure and styling

---

**Last Updated:** November 12, 2025
**Project:** Diseño de Experimentos - Agriculture Optimization Dashboard
**Team:** Yeison Poveda, Victor Díaz
